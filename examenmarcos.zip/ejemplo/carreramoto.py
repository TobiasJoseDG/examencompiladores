import pygame
import sys
import random

# Inicializar Pygame
pygame.init()

# Configuración de la ventana
WIDTH, HEIGHT = 800, 600
WIN = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Carrera de Motos")

# Colores
WHITE = (255, 255, 255)
RED = (255, 0, 0)
BLUE = (0, 0, 255)
GRAY = (128, 128, 128)

# Jugador 1 (WASD)
player1_size = 50
player1_pos = [100, HEIGHT // 2]
player1_speed = 5

# Jugador 2 (Teclas de flecha)
player2_size = 50
player2_pos = [WIDTH - 100, HEIGHT // 2]
player2_speed = 5

# Obstáculos
obstacle_width = 50
obstacle_height = 50
obstacle_speed = 5
obstacles = []

def create_obstacle():
    x = random.randint(0, WIDTH - obstacle_width)
    y = -obstacle_height  # Los obstáculos vienen desde arriba
    obstacles.append(pygame.Rect(x, y, obstacle_width, obstacle_height))

def move_obstacles():
    for obstacle in obstacles:
        obstacle.y += obstacle_speed

# Función para actualizar la pantalla
def draw():
    WIN.fill(WHITE)
    pygame.draw.rect(WIN, RED, (player1_pos[0], player1_pos[1], player1_size, player1_size))
    pygame.draw.rect(WIN, BLUE, (player2_pos[0], player2_pos[1], player2_size, player2_size))
    for obstacle in obstacles:
        pygame.draw.rect(WIN, GRAY, obstacle)
    pygame.display.update()

# Bucle principal
run = True
clock = pygame.time.Clock()
while run:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False

    # Jugador 1 (WASD)
    keys = pygame.key.get_pressed()
    if keys[pygame.K_w] and player1_pos[1] > 0:
        player1_pos[1] -= player1_speed
    if keys[pygame.K_s] and player1_pos[1] < HEIGHT - player1_size:
        player1_pos[1] += player1_speed
    if keys[pygame.K_a] and player1_pos[0] > 0:
        player1_pos[0] -= player1_speed
    if keys[pygame.K_d] and player1_pos[0] < WIDTH / 2 - player1_size:
        player1_pos[0] += player1_speed

    # Jugador 2 (Teclas de flecha)
    if keys[pygame.K_UP] and player2_pos[1] > 0:
        player2_pos[1] -= player2_speed
    if keys[pygame.K_DOWN] and player2_pos[1] < HEIGHT - player2_size:
        player2_pos[1] += player2_speed
    if keys[pygame.K_LEFT] and player2_pos[0] > WIDTH / 2:
        player2_pos[0] -= player2_speed
    if keys[pygame.K_RIGHT] and player2_pos[0] < WIDTH - player2_size:
        player2_pos[0] += player2_speed

    # Crear nuevos obstáculos
    if random.randint(0, 100) < 10:  # Probabilidad de 10% de crear un nuevo obstáculo
        create_obstacle()

    # Mover obstáculos
    move_obstacles()

    # Verificar colisiones con obstáculos
    for obstacle in obstacles:
        if player1_pos[0] + player1_size > obstacle.x and player1_pos[0] < obstacle.x + obstacle_width:
            if player1_pos[1] + player1_size > obstacle.y and player1_pos[1] < obstacle.y + obstacle_height:
                print("¡Colisión! Jugador 1 ha perdido.")
                run = False
        if player2_pos[0] + player2_size > obstacle.x and player2_pos[0] < obstacle.x + obstacle_width:
            if player2_pos[1] + player2_size > obstacle.y and player2_pos[1] < obstacle.y + obstacle_height:
                print("¡Colisión! Jugador 2 ha perdido.")
                run = False

    # Verificar si las motos están fuera de la ventana
    if player1_pos[0] < 0 or player1_pos[0] > WIDTH or player1_pos[1] < 0 or player1_pos[1] > HEIGHT:
        print("¡Jugador 1 ha salido de la ventana!")
        run = False
    if player2_pos[0] < 0 or player2_pos[0] > WIDTH or player2_pos[1] < 0 or player2_pos[1] > HEIGHT:
        print("¡Jugador 2 ha salido de la ventana!")
        run = False

    draw()
    clock.tick(30)

pygame.quit()
sys.exit()
