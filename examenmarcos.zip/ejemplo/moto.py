import pygame
import sys
import random

# Inicializar Pygame
pygame.init()

# Configuración de la ventana
WIDTH, HEIGHT = 800, 600
ROAD_WIDTH = 400
ROAD_MARGIN = (WIDTH - ROAD_WIDTH) // 2
WIN = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Carrera de Motos por Turnos")

# Cargar imágenes y ajustar tamaño
player_img = pygame.image.load('moto.png')  
player_img = pygame.transform.scale(player_img, (ROAD_WIDTH // 4, ROAD_WIDTH // 4))

obstacle_img = pygame.image.load('obstaculo.png')  
obstacle_img = pygame.transform.scale(obstacle_img, (ROAD_WIDTH // 4, ROAD_WIDTH // 4))

# Jugador (auto)
player_size = ROAD_WIDTH // 4
player_pos = [WIDTH // 2 - player_size // 2, HEIGHT - 100 - player_size // 2]
player_speed = 8

# Obstáculos
obstacle_width = ROAD_WIDTH // 4
obstacle_height = ROAD_WIDTH // 4
initial_obstacle_speed = 5
obstacle_speed = initial_obstacle_speed
obstacles = []
min_distance_between_obstacles = 200

# Árboles
trees = []
num_trees = 10  # Número de árboles
for _ in range(num_trees):
    x = random.randint(50, WIDTH - 50)
    y = random.randint(100, HEIGHT - 100)
    # Asegurar que los árboles estén fuera de la carretera
    while ROAD_MARGIN <= x <= ROAD_MARGIN + ROAD_WIDTH:
        x = random.randint(50, WIDTH - 50)
    trees.append((x, y))

# Turnos
current_player = 1
scores = {1: 0, 2: 0}

# Función para crear obstáculos
def create_obstacle():
    if len(obstacles) == 0 or obstacles[-1]['rect'].y > min_distance_between_obstacles:
        x = random.randint(ROAD_MARGIN, ROAD_MARGIN + ROAD_WIDTH - obstacle_width)
        y = -obstacle_height
        obstacles.append({'rect': pygame.Rect(x, y, obstacle_width, obstacle_height), 'img': obstacle_img})

# Función para mover obstáculos y aumentar la velocidad
def move_obstacles():
    global obstacle_speed
    for obstacle in obstacles:
        obstacle['rect'].y += obstacle_speed
    obstacles[:] = [obstacle for obstacle in obstacles if obstacle['rect'].y < HEIGHT]

    # Aumentar la velocidad cada 10 obstáculos
    if len(obstacles) > 0 and len(obstacles) % 10 == 0:
        obstacle_speed += 2

# Función para dibujar en la pantalla
def draw():
    WIN.fill((128, 128, 128))  # Fondo gris
    pygame.draw.rect(WIN, (0, 0, 0), (ROAD_MARGIN, 0, ROAD_WIDTH, HEIGHT))  # Carretera negra
    for y in range(0, HEIGHT, 60):
        pygame.draw.rect(WIN, (255, 255, 0), (WIDTH // 2 - 5, y, 10, 40))  # Marcas amarillas en la carretera

    # Dibujar árboles
    for tree in trees:
        draw_tree(tree[0], tree[1])

    # Dibujar jugador
    WIN.blit(player_img, player_pos)

    # Dibujar obstáculos
    for obstacle in obstacles:
        WIN.blit(obstacle['img'], obstacle['rect'])

    pygame.display.update()

# Función para dibujar un árbol
def draw_tree(x, y):
    pygame.draw.rect(WIN, (139, 69, 19), (x - 10, y + 20, 20, 40))  # Tronco
    pygame.draw.circle(WIN, (34, 139, 34), (x, y), 30)  # Hojas

# Función principal del juego
def game():
    global player_pos, obstacles, current_player, scores
    player_pos = [WIDTH // 2 - player_size // 2, HEIGHT - 100 - player_size // 2]
    obstacles = []
    run = True
    max_distance = 0  # Variable para almacenar la máxima distancia alcanzada en el turno
    clock = pygame.time.Clock()
    while run:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run = False

        keys = pygame.key.get_pressed()
        if keys[pygame.K_w] and player_pos[1] > 0:
            player_pos[1] -= player_speed
        if keys[pygame.K_s] and player_pos[1] < HEIGHT - player_size:
            player_pos[1] += player_speed
        if keys[pygame.K_a] and player_pos[0] > ROAD_MARGIN:
            player_pos[0] -= player_speed
        if keys[pygame.K_d] and player_pos[0] < ROAD_MARGIN + ROAD_WIDTH - player_size:
            player_pos[0] += player_speed

        if random.randint(0, 100) < 10:
            create_obstacle()

        move_obstacles()

        # Calcular la distancia máxima alcanzada por el jugador en este turno
        current_distance = len(obstacles)
        if current_distance > max_distance:
            max_distance = current_distance

        for obstacle in obstacles:
            if player_pos[0] + player_size > obstacle['rect'].x and player_pos[0] < obstacle['rect'].x + obstacle_width:
                if player_pos[1] + player_size > obstacle['rect'].y and player_pos[1] < obstacle['rect'].y + obstacle_height:
                    run = False

        if player_pos[0] < ROAD_MARGIN or player_pos[0] > ROAD_MARGIN + ROAD_WIDTH - player_size or player_pos[1] < 0 or player_pos[1] > HEIGHT:
            run = False

        draw()
        clock.tick(30)

    # Actualizar el puntaje del jugador actual con la distancia máxima alcanzada
    scores[current_player] += max_distance

    if current_player == 1:
        current_player = 2
        game_over_screen("Turno del Jugador 2")
    else:
        determine_winner()

# Función para mostrar la pantalla de Game Over
def game_over_screen(message):
    WIN.fill((0, 0, 0))  # Fondo negro
    font = pygame.font.SysFont(None, 48)
    game_over_text = font.render(message, True, (255, 0, 0))  # Texto rojo
    WIN.blit(game_over_text, (WIDTH // 2 - game_over_text.get_width() // 2, HEIGHT // 2 - game_over_text.get_height() // 2))
    pygame.display.update()
    pygame.time.wait(2000)
    game()

# Función para determinar el ganador
def determine_winner():
    global scores
    WIN.fill((0, 0, 0))  # Fondo negro
    font = pygame.font.SysFont(None, 48)
    if scores[1] > scores[2]:
        winner_text = font.render("¡Gana el Jugador 1!", True, (255, 0, 0))  # Texto rojo
    elif scores[1] < scores[2]:
        winner_text = font.render("¡Gana el Jugador 2!", True, (255, 0, 0))  # Texto rojo
    else:
        winner_text = font.render("¡Es un empate!", True, (255, 0, 0))  # Texto rojo
    
    game_over_text = font.render("Juego Terminado", True, (255, 0, 0))  # Mensaje de juego terminado
    WIN.blit(winner_text, (WIDTH // 2 - winner_text.get_width() // 2, HEIGHT // 2 - winner_text.get_height() // 2 - 50))
    WIN.blit(game_over_text, (WIDTH // 2 - game_over_text.get_width() // 2, HEIGHT // 2 - game_over_text.get_height() // 2 + 50))
    pygame.display.update()
    pygame.time.wait(5000)
    pygame.quit()
    sys.exit()

# Iniciar el juego
game()
