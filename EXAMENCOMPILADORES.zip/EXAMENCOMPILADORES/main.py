import pygame
import sys
import subprocess  # Para ejecutar otro script Python

# Inicializa Pygame
pygame.init()

# Configura la pantalla
screen_width = 800
screen_height = 600
screen = pygame.display.set_mode((screen_width, screen_height))
pygame.display.set_caption("Menú Principal")

# Colores
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)

# Fuentes
font = pygame.font.SysFont(None, 55)
small_font = pygame.font.SysFont(None, 35)

# Función para crear texto
def text_objects(text, font, color):
    text_surface = font.render(text, True, color)
    return text_surface, text_surface.get_rect()

# Función para los botones
def button(msg, x, y, width, height, action=None):
    mouse = pygame.mouse.get_pos()
    click = pygame.mouse.get_pressed()

    text_surf, text_rect = text_objects(msg, font, WHITE)
    text_rect.center = (x, y)
    
    if x - width // 2 < mouse[0] < x + width // 2 and y - height // 2 < mouse[1] < y + height // 2:
        if click[0] == 1 and action is not None:
            action()
    
    screen.blit(text_surf, text_rect)

# Función para salir del juego
def quit_game():
    pygame.quit()
    sys.exit()

# Función para iniciar el juego
def start_game():
    pygame.quit()  # Cierra la ventana del menú principal
    subprocess.run(["python", "juego.py"])  # Ejecuta juego.py usando subprocess

# Función para mostrar configuraciones
def show_settings():
    settings = True
    while settings:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                quit_game()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    settings = False
        
        screen.fill(BLACK)
        lines = [
            "Para mover al auto usa las teclas:",
            "izquierda, derecha, arriba y abajo."
        ]
        y_offset = screen_height // 2 - 40  # Ajusta la posición vertical para centrar
        for line in lines:
            settings_text, settings_rect = text_objects(line, small_font, WHITE)
            settings_rect.center = ((screen_width / 2), y_offset)
            screen.blit(settings_text, settings_rect)
            y_offset += 50  # Espacio entre las líneas
        pygame.display.update()

# Función para mostrar créditos
def show_credits():
    credits = True
    while credits:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                quit_game()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    credits = False
        
        screen.fill(BLACK)
        credits_text, credits_rect = text_objects("Creado por www.tobigames.com", small_font, WHITE)
        credits_rect.center = ((screen_width / 2), (screen_height / 2))
        screen.blit(credits_text, credits_rect)
        pygame.display.update()

# Función para mostrar instrucciones
def show_instructions():
    instructions = True
    while instructions:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                quit_game()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    instructions = False
        
        screen.fill(BLACK)
        instructions_text = [
            "1. Esquivar todos los autos posibles.",
            "2. Conseguir récord de puntos.",
            "3. Llegar al máximo nivel."
        ]
        y_offset = screen_height // 2 - 40  # Ajusta la posición vertical para centrar
        for index, line in enumerate(instructions_text):
            instruction_text, instruction_rect = text_objects(line, small_font, WHITE)
            instruction_rect.center = ((screen_width / 2), y_offset + index * 50)
            screen.blit(instruction_text, instruction_rect)
        pygame.display.update()

# Loop del menú principal
def main_menu():
    menu = True
    while menu:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                quit_game()
        
        screen.fill(BLACK)

        button("Jugar", screen_width // 2, 150, 200, 50, start_game)
        button("Instrucciones", screen_width // 2, 250, 200, 50, show_instructions)
        button("Controles", screen_width // 2, 350, 200, 50, show_settings)
        button("Créditos", screen_width // 2, 450, 200, 50, show_credits)
        button("Salir", screen_width // 2, 550, 200, 50, quit_game)

        pygame.display.update()

# Inicia el menú principal
main_menu()
