import pygame
import sys
import subprocess  # Importa subprocess para ejecutar otro script Python

# Inicializa Pygame
pygame.init()

# Configuración de la ventana
ANCHO, ALTO = 800, 600
ventana = pygame.display.set_mode((ANCHO, ALTO))
pygame.display.set_caption("Game Over!")

# Colores
BLANCO = (255, 255, 255)
NEGRO = (0, 0, 0)

# Fuentes
fuente_grande = pygame.font.Font(None, 72)
fuente_pequeña = pygame.font.Font(None, 36)

# Función para crear texto
def text_objects(text, font, color):
    text_surface = font.render(text, True, color)
    return text_surface, text_surface.get_rect()

# Función para mostrar mensaje de Game Over
def mostrar_game_over():
    mensaje_game_over, rect_game_over = text_objects("GAME OVER", fuente_grande, BLANCO)
    rect_game_over.center = (ANCHO // 2, ALTO // 2 - 50)

    boton_salir, rect_salir = text_objects("Salir", fuente_pequeña, BLANCO)
    rect_salir.center = (ANCHO // 2, ALTO // 2 + 50)

    ventana.fill(NEGRO)
    ventana.blit(mensaje_game_over, rect_game_over)
    ventana.blit(boton_salir, rect_salir)

    pygame.display.update()

    # Espera a que el jugador seleccione una opción
    while True:
        for evento in pygame.event.get():
            if evento.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if evento.type == pygame.MOUSEBUTTONDOWN:
                x, y = pygame.mouse.get_pos()
                if rect_salir.collidepoint(x, y):
                    pygame.quit()
                    sys.exit()

# Llama a la función principal de game_over_menu.py
if __name__ == "__main__":
    mostrar_game_over()

