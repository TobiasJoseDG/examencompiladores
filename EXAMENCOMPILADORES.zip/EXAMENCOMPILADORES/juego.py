import pygame
import random
import sys
import subprocess  # Importa subprocess para ejecutar otro script Python

# Inicializar Pygame
pygame.init()

# Configuración de la ventana
ANCHO, ALTO = 800, 600
ventana = pygame.display.set_mode((ANCHO, ALTO))
pygame.display.set_caption("Juego de Autos")

# Colores
BLANCO = (255, 255, 255)
AZUL = (0, 0, 255)
GRIS = (128, 128, 128)

# Configuración del auto
ancho_auto, alto_auto = 60, 120
pos_auto_x = ANCHO // 2 - ancho_auto // 2
pos_auto_y = ALTO - alto_auto - 20
vel_auto = 8

# Configuración de los obstáculos
ancho_obstaculo, alto_obstaculo = ancho_auto, alto_auto  # Mismo tamaño que el auto
vel_obstaculo_base = 8  # Aumentar la velocidad de los obstáculos
brecha_obstaculo = 10 # Reducir la distancia entre obstáculos
obstaculo_actual = None
puntos = 0
nivel = 1
incremento_velocidad = 0.1
max_nivel = 5

# Configuración de la autopista
ancho_autopista = 300  # Ancho de la autopista
pos_autopista_x = ANCHO // 2 - ancho_autopista // 2
divisores = [(pos_autopista_x + (ancho_autopista // 2) - 2, 0), (pos_autopista_x + (ancho_autopista // 2) - 2, ALTO)]

# Cargar imagen del auto
imagen_auto = pygame.image.load("car_image.png")
imagen_auto = pygame.transform.scale(imagen_auto, (ancho_auto, alto_auto))

# Cargar imagen del obstáculo
imagen_obstaculo = pygame.image.load("obstacle_image.png")
imagen_obstaculo = pygame.transform.scale(imagen_obstaculo, (ancho_obstaculo, alto_obstaculo))

# Cargar sonido de colisión
sonido_colision = pygame.mixer.Sound("colision.mp3")

# Mensajes
fuente = pygame.font.Font(None, 36)

# Reloj para controlar la velocidad de actualización
reloj = pygame.time.Clock()

# Función para generar un nuevo obstáculo
def generar_obstaculo():
    global obstaculo_actual
    if not obstaculo_actual:
        pos_obstaculo_x = random.randint(pos_autopista_x, pos_autopista_x + ancho_autopista - ancho_obstaculo)
        pos_obstaculo_y = -alto_obstaculo
        obstaculo_actual = pygame.Rect(pos_obstaculo_x, pos_obstaculo_y, ancho_obstaculo, alto_obstaculo)

# Función para mover el obstáculo actual
def mover_obstaculo():
    global obstaculo_actual, vel_obstaculo_base, puntos, nivel
    if obstaculo_actual:
        obstaculo_actual.y += vel_obstaculo_base
        if obstaculo_actual.y > ALTO:
            obstaculo_actual = None
            puntos += 100
            if puntos % 1100 == 0 and nivel < max_nivel:
                nivel += 1
                vel_obstaculo_base *= (1 + incremento_velocidad)
                print(f"¡Subiste al nivel {nivel}!")

# Función para detectar colisiones y mostrar el menú de Game Over
def verificar_colision():
    global pos_auto_x, pos_auto_y, ancho_auto, alto_auto
    rect_auto = pygame.Rect(pos_auto_x, pos_auto_y, ancho_auto, alto_auto)
    if obstaculo_actual and rect_auto.colliderect(obstaculo_actual):
        sonido_colision.play()  # Reproduce sonido de colisión
        pygame.time.delay(1000)  # Breve pausa para que el jugador vea la colisión
        return True
    return False

# Función para dibujar la pantalla
def dibujar_pantalla():
    ventana.fill(BLANCO)  # Fondo blanco

    # Dibujar la carretera
    pygame.draw.rect(ventana, GRIS, (0, 0, pos_autopista_x, ALTO))  # Lateral izquierdo gris
    pygame.draw.rect(ventana, GRIS, (pos_autopista_x + ancho_autopista, 0, ANCHO - (pos_autopista_x + ancho_autopista), ALTO))  # Lateral derecho gris
    pygame.draw.rect(ventana, BLANCO, (pos_autopista_x, 0, ancho_autopista, ALTO))  # Autopista blanca
    pygame.draw.rect(ventana, GRIS, (pos_autopista_x, 0, 4, ALTO))  # Límite lateral izquierdo gris
    pygame.draw.rect(ventana, GRIS, (pos_autopista_x + ancho_autopista - 4, 0, 4, ALTO))  # Límite lateral derecho gris
    pygame.draw.rect(ventana, GRIS, (pos_autopista_x, 0, ancho_autopista, 4))  # Línea superior gris
    for divisor in divisores:
        pygame.draw.rect(ventana, GRIS, (divisor[0], divisor[1], 4, ALTO))  # Líneas divisorias grises

    # Dibujar el auto del jugador
    ventana.blit(imagen_auto, (pos_auto_x, pos_auto_y))

    # Dibujar obstáculo actual
    if obstaculo_actual:
        ventana.blit(imagen_obstaculo, obstaculo_actual)

    # Mostrar puntos en la ventana
    texto_puntos = fuente.render("Puntos: {}".format(puntos), True, AZUL)
    ventana.blit(texto_puntos, (20, 20))

    # Mostrar nivel en la ventana
    texto_nivel = fuente.render("Nivel: {}".format(nivel), True, AZUL)
    ventana.blit(texto_nivel, (20, 60))

    # Actualizar pantalla
    pygame.display.update()

    # Controlar la velocidad de actualización
    reloj.tick(60)

# Bucle principal del juego
def main():
    global pos_auto_x, pos_auto_y, ancho_auto, alto_auto, obstaculo_actual, puntos, nivel, vel_obstaculo_base

    corriendo = True
    while corriendo:
        for evento in pygame.event.get():
            if evento.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

        teclas = pygame.key.get_pressed()
        if teclas[pygame.K_LEFT] and pos_auto_x > pos_autopista_x:
            pos_auto_x -= vel_auto
        if teclas[pygame.K_RIGHT] and pos_auto_x < pos_autopista_x + ancho_autopista - ancho_auto:
            pos_auto_x += vel_auto
        if teclas[pygame.K_UP] and pos_auto_y > 0:  # Movimiento hacia arriba
            pos_auto_y -= vel_auto
        if teclas[pygame.K_DOWN] and pos_auto_y < ALTO - alto_auto:  # Movimiento hacia abajo
            pos_auto_y += vel_auto

        # Generar y mover obstáculo actual
        generar_obstaculo()
        mover_obstaculo()

        # Verificar colisiones
        if verificar_colision():
            subprocess.run(["python", "game_over_menu.py"])  # Llama a game_over_menu.py
            pygame.quit()  # Cierra la ventana del juego
            return  # Sale del bucle del juego

        # Dibujar la pantalla
        dibujar_pantalla()

if __name__ == "__main__":
    main()
